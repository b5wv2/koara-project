const express = require('express');
const router = express.Router();
const db = require('../config/db');
const topupCatalogService = require('../services/topupCatalogService');
const topupOrderService = require('../services/topupOrderService');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, '../../uploads'));
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'receipt-topup-' + uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({ 
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, 
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|webp|pdf/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    if (extname && mimetype) {
      return cb(null, true);
    } else {
      cb(new Error('Only images and PDF files are allowed!'));
    }
  }
});

// GET /api/store/:storeId/topups/catalog
router.get('/catalog/:storeId', async (req, res) => {
  const { storeId } = req.params;

  try {
    const catalogs = topupCatalogService.getCatalogs();

    const merchantProductsRes = await db.query(`
      SELECT offer_id, selling_price, custom_image_url 
      FROM merchant_topup_products 
      WHERE store_id = $1 AND is_enabled = true
    `, [storeId]);
    
    const merchantMap = {};
    merchantProductsRes.rows.forEach(row => {
      merchantMap[row.offer_id] = {
        selling_price: row.selling_price,
        custom_image_url: row.custom_image_url
      };
    });

    const merchantCategoriesRes = await db.query(`
      SELECT category_id, custom_image_url, custom_description
      FROM merchant_topup_categories
      WHERE store_id = $1
    `, [storeId]);

    const merchantCatMap = {};
    merchantCategoriesRes.rows.forEach(row => {
      merchantCatMap[row.category_id] = {
        custom_image_url: row.custom_image_url,
        custom_description: row.custom_description
      };
    });

    const activeCatalogs = [];

    catalogs.forEach(catalog => {
      const catMeta = merchantCatMap[catalog.category_id] || {};
      const categoryImageUrl = catMeta.custom_image_url || catalog.image_url || null;

      const activeOffers = catalog.offers
        .filter(offer => merchantMap[offer.offer_id] !== undefined)
        .map(offer => {
          const mOffer = merchantMap[offer.offer_id];
          return {
            offer_id: offer.offer_id,
            name: offer.name,
            selling_price: mOffer.selling_price,
            image_url: mOffer.custom_image_url || offer.image_url || categoryImageUrl || null
          };
        });

      if (activeOffers.length > 0) {
        activeCatalogs.push({
          category: {
            id: catalog.category_id,
            name: catalog.name,
            note: catMeta.custom_description || catalog.note || '',
            image_url: categoryImageUrl
          },
          fields: catalog.fields || [],
          offers: activeOffers
        });
      }
    });

    res.json({ 
      success: true, 
      catalogs: activeCatalogs 
    });
  } catch (err) {
    console.error('Error fetching storefront topups catalog:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/store/:storeId/topups/order
router.post('/order/:storeId', upload.single('receipt'), async (req, res) => {
  const { storeId } = req.params;
  let { offerId, fields, customerName, customerEmail, whatsapp, promoCode } = req.body;

  if (!offerId || !fields || !customerName || !customerEmail || !whatsapp) {
    return res.status(400).json({ error: 'Missing required order fields.' });
  }

  if (!req.file) {
    return res.status(400).json({ error: 'Payment receipt is required for top-up orders' });
  }

  const receiptUrl = `/uploads/${req.file.filename}`;

  // If fields is sent via FormData it might be a string
  if (typeof fields === 'string') {
    try {
      fields = JSON.parse(fields);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid fields format' });
    }
  }

  try {
    const result = await topupOrderService.createPendingOrder({
      storeId,
      offerId,
      dynamicFields: fields,
      customerInfo: { name: customerName, email: customerEmail, whatsapp },
      receiptUrl,
      promoCode
    });

    res.status(201).json({ success: true, order: result });
  } catch (err) {
    console.error('Checkout failed for topup:', err.message);
    res.status(400).json({ success: false, error: err.message });
  }
});

module.exports = router;
