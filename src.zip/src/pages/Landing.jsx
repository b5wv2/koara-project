import React, { useState, useEffect, useRef } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import OnboardingModal from '../components/OnboardingModal';
import LoginModal from '../components/LoginModal';
import StoreStatusModal from '../components/StoreStatusModal';
import PasswordResetModal from '../components/PasswordResetModal';
import { Store, Wallet, ShieldCheck, FileText, BarChart2, TrendingUp, ArrowRight, Zap, Globe, Lock, ChevronDown, MessageCircle } from 'lucide-react';
import { FaWhatsapp, FaFacebook, FaXTwitter } from 'react-icons/fa6';
import { useAppContext } from '../context/AppContext';
import AmbientWaveBackground from '../components/AmbientWaveBackground';
import InteractiveGrid from '../components/InteractiveGrid';
import LightPillar from '../components/LightPillar';

const FeatureCard = ({ icon: Icon, title, description }) => (
  <div className="glass-card p-7 relative z-10 group transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_20px_40px_-15px_rgba(0,0,0,0.5)]">
    <div className="feature-icon mb-5 group-hover:scale-110 transition-transform duration-300">
      <Icon size={22} />
    </div>
    <h3 className="font-bold text-lg mb-2.5 text-white">{title}</h3>
    <p className="text-slate-400 text-sm leading-relaxed">{description}</p>
  </div>
);

const FAQItem = ({ question, answer, isOpen, onClick }) => (
  <div className={`glass-card mb-4 overflow-hidden transition-all duration-300 border ${isOpen ? 'border-white/20 shadow-lg shadow-white/5' : 'border-white/5 hover:border-white/10'}`}>
    <button
      className="w-full px-6 py-6 sm:px-8 text-left flex items-center justify-between focus:outline-none cursor-pointer"
      onClick={onClick}
    >
      <span className="font-semibold text-white text-base sm:text-lg pr-4">{question}</span>
      <ChevronDown className={`text-slate-400 shrink-0 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} size={24} />
    </button>
    <div className={`grid transition-all duration-300 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
      <div className="overflow-hidden">
        <div className="px-6 pb-6 sm:px-8 sm:pb-8 pt-2 text-slate-400 text-sm sm:text-base leading-relaxed">
          {answer}
        </div>
      </div>
    </div>
  </div>
);

const LandingPage = () => {
  const pricingRef = useRef(null);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [onboardingInitialData, setOnboardingInitialData] = useState(null);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isPasswordResetOpen, setIsPasswordResetOpen] = useState(false);
  const [storeRequestStatus, setStoreRequestStatus] = useState(null);
  const { t } = useAppContext();
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
        }
      });
    }, { threshold: 0.1, rootMargin: "0px 0px -50px 0px" });

    document.querySelectorAll('.fade-in-section').forEach((el) => {
      observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);


  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden" style={{ background: '#020617' }}>
      <AmbientWaveBackground />
      <InteractiveGrid />

      <Header
        onStartSelling={() => setIsOnboardingOpen(true)}
        onSignIn={() => setIsLoginOpen(true)}
      />

      <main className="flex-1 relative z-10">
        {/* ═══════════════════════════════════════════════════════════════
            HERO SECTION
        ═══════════════════════════════════════════════════════════════ */}
        <section className="max-w-5xl mx-auto px-4 sm:px-8 pt-20 sm:pt-32 pb-24 sm:pb-36 relative text-center">
          <div className="flex flex-col items-center justify-center relative">

            {/* Hero Content */}
            <div className="w-full relative flex flex-col items-center justify-center z-10">

              <div className="text-xs font-bold uppercase tracking-[0.2em] mb-6 inline-flex items-center justify-center gap-3 fade-in-section stagger-1" style={{ color: '#60A5FA' }}>
                <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#3B82F6' }}></span>
                PLATFORM OVERVIEW
              </div>

              {/* Headline with LightPillar effect behind the text */}
              <div className="relative mb-8 w-full max-w-4xl fade-in-section stagger-2">
                {/* Dark radial backdrop — provides contrast for the LightPillar */}
                <div className="hero-light-backdrop" aria-hidden="true" />
                {/* LightPillar layer — sits below the text via z-index */}
                <div className="hero-light-effect" aria-hidden="true">
                  <LightPillar
                    topColor="#4438fa"
                    bottomColor="#00bfff"
                    intensity={0.9}
                    rotationSpeed={0.2}
                    glowAmount={0.0015}
                    pillarWidth={3}
                    pillarHeight={0.4}
                    noiseIntensity={0.25}
                    pillarRotation={25}
                    interactive={false}
                    mixBlendMode="normal"
                    quality="low"
                  />
                </div>
                <h1
                  className="relative z-10 text-4xl sm:text-6xl md:text-[5.5rem] font-extrabold tracking-tight leading-[1.05] text-gradient-premium"
                  style={{ textShadow: '0 2px 20px rgba(0,0,0,0.3)' }}
                >
                  A single platform,<br />
                  a year's worth<br />
                  of impact.
                </h1>
              </div>

              <p className="text-lg sm:text-xl mb-10 max-w-2xl leading-relaxed font-medium mx-auto fade-in-section stagger-3" style={{ color: '#94A3B8' }}>
                Start selling digital products in MENA seamlessly. No coding required. Handle KYC, accept payments, and automatically deliver digital codes in seconds.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 fade-in-section stagger-4 w-full sm:w-auto px-4">
                <button
                  onClick={() => pricingRef.current?.scrollIntoView({ behavior: 'smooth' })}
                  className="btn-primary px-8 py-4 text-base flex items-center justify-center gap-2 w-full sm:w-auto"
                >
                  {t('start_store_free')} <ArrowRight size={18} className="rtl:rotate-180" />
                </button>
                <button className="btn-secondary px-6 py-4 text-sm w-full sm:w-auto">
                  Watch demo
                </button>
              </div>

              {/* Social Media Row */}
              <div className="mt-14 flex items-center justify-center gap-6 fade-in-section stagger-4">
                <a href="https://www.whatsapp.com/" target="_blank" rel="noopener noreferrer" className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 hover:scale-110 transition-all duration-300 shadow-[0_0_15px_rgba(255,255,255,0.05)] hover:shadow-[0_0_25px_rgba(255,255,255,0.15)] group">
                  <FaWhatsapp size={26} className="text-slate-400 group-hover:text-white transition-colors" />
                </a>
                <a href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer" className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 hover:scale-110 transition-all duration-300 shadow-[0_0_15px_rgba(255,255,255,0.05)] hover:shadow-[0_0_25px_rgba(255,255,255,0.15)] group">
                  <FaFacebook size={26} className="text-slate-400 group-hover:text-white transition-colors" />
                </a>
                <a href="https://www.x.com/" target="_blank" rel="noopener noreferrer" className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 hover:scale-110 transition-all duration-300 shadow-[0_0_15px_rgba(255,255,255,0.05)] hover:shadow-[0_0_25px_rgba(255,255,255,0.15)] group">
                  <FaXTwitter size={26} className="text-slate-400 group-hover:text-white transition-colors" />
                </a>
              </div>
            </div>

          </div>
        </section>

        {/* ═══════════════════════════════════════════════════════════════
            STATS / SOCIAL PROOF SECTION
        ═══════════════════════════════════════════════════════════════ */}
        <section className="max-w-7xl mx-auto px-4 sm:px-8 pb-20 sm:pb-28 relative z-10 fade-in-section">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              ['800+', 'Active Merchants'],
              ['$2.1k', 'Monthly Volume'],
              ['99.9%', 'Uptime SLA'],
              ['<1s', 'Delivery Speed']
            ].map(([value, label]) => (
              <div key={label} className="glass-card text-center py-8 px-4">
                <div className="stat-value mb-2">{value}</div>
                <div className="text-sm font-medium" style={{ color: '#94A3B8' }}>{label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════════════════
            FEATURES SECTION
        ═══════════════════════════════════════════════════════════════ */}
        <section className="max-w-7xl mx-auto px-4 sm:px-8 py-20 sm:py-28 relative z-10 section-glow fade-in-section">
          <div className="mb-16 text-center">
            <div className="text-xs font-bold uppercase tracking-[0.2em] mb-4 inline-flex items-center gap-2" style={{ color: '#60A5FA' }}>
              <Zap size={14} />
              FEATURES
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white mb-6">{t('features_title')}</h2>
            <p className="text-lg sm:text-xl max-w-2xl mx-auto" style={{ color: '#94A3B8' }}>
              From merchant KYC to wallet ledger entries, the whole commerce lifecycle ships as one cohesive system, beautifully integrated.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
            <FeatureCard
              icon={Store}
              title={t('feature_1_title')}
              description={t('feature_1_desc')}
            />
            <FeatureCard
              icon={Wallet}
              title={t('feature_2_title')}
              description={t('feature_2_desc')}
            />
            <FeatureCard
              icon={ShieldCheck}
              title="KYC Onboarding"
              description="Multi-step verification with bank details and ID document review natively integrated."
            />
            <FeatureCard
              icon={FileText}
              title="Receipt Inspection"
              description="Customers upload bank transfer slips seamlessly. Merchants approve or reject instantly."
            />
            <FeatureCard
              icon={BarChart2}
              title="Data-Rich Dashboards"
              description="Revenue charts, transaction ledgers, and platform-wide analytics at your fingertips."
            />
            <FeatureCard
              icon={TrendingUp}
              title={t('feature_3_title')}
              description={t('feature_3_desc')}
            />
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════════════════
            HOW IT WORKS SECTION
        ═══════════════════════════════════════════════════════════════ */}
        <section className="max-w-7xl mx-auto px-4 sm:px-8 py-20 sm:py-28 relative z-10 section-glow fade-in-section">
          <div className="mb-16 text-center">
            <div className="text-xs font-bold uppercase tracking-[0.2em] mb-4 inline-flex items-center gap-2" style={{ color: '#60A5FA' }}>
              <Globe size={14} />
              HOW IT WORKS
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white mb-6">Three steps to launch</h2>
            <p className="text-lg max-w-xl mx-auto" style={{ color: '#94A3B8' }}>
              Go from zero to live storefront in minutes, not weeks.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Create your store', desc: 'Sign up, complete KYC verification, and configure your digital product catalog.' },
              { step: '02', title: 'Connect payments', desc: 'Link your bank account or wallet. We handle the payment processing and settlements.' },
              { step: '03', title: 'Start selling', desc: 'Share your storefront link. Orders are fulfilled automatically with instant code delivery.' }
            ].map(({ step, title, desc }) => (
              <div key={step} className="glass-card p-8 relative group">
                <div className="text-5xl font-black mb-6" style={{ color: 'rgba(37,99,235,0.15)' }}>{step}</div>
                <h3 className="text-lg font-bold text-white mb-3">{title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: '#94A3B8' }}>{desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════════════════
            SECURITY / TRUST SECTION
        ═══════════════════════════════════════════════════════════════ */}
        <section className="max-w-7xl mx-auto px-4 sm:px-8 py-20 sm:py-28 relative z-10 section-glow fade-in-section">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="text-xs font-bold uppercase tracking-[0.2em] mb-4 inline-flex items-center gap-2" style={{ color: '#60A5FA' }}>
                <Lock size={14} />
                ENTERPRISE SECURITY
              </div>
              <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mb-6">
                Built for trust.<br />Designed for scale.
              </h2>
              <p className="text-lg leading-relaxed mb-8" style={{ color: '#94A3B8' }}>
                Every transaction is encrypted, every merchant is verified, and every wallet balance is reconciled in real-time. Your data never leaves our secure infrastructure.
              </p>
              <div className="flex flex-wrap gap-3">
                {['End-to-End Encryption', 'KYC Verified', 'PCI Compliant', 'Real-time Audit Logs'].map(tag => (
                  <span key={tag} className="text-xs font-semibold px-3 py-1.5 rounded-full" style={{ background: 'rgba(37,99,235,0.1)', border: '1px solid rgba(37,99,235,0.2)', color: '#60A5FA' }}>
                    {tag}
                  </span>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { val: '256-bit', label: 'AES Encryption' },
                { val: '100%', label: 'KYC Coverage' },
                { val: '<50ms', label: 'API Latency' },
                { val: '24/7', label: 'Monitoring' }
              ].map(({ val, label }) => (
                <div key={label} className="glass-card p-6 text-center">
                  <div className="text-2xl font-extrabold text-white mb-1">{val}</div>
                  <div className="text-xs font-medium" style={{ color: '#94A3B8' }}>{label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════════════════
            PRICING / SUBSCRIPTION SECTION
        ═══════════════════════════════════════════════════════════════ */}
        <section ref={pricingRef} className="max-w-7xl mx-auto px-4 sm:px-8 py-20 sm:py-28 relative z-10 section-glow fade-in-section">
          <div className="mb-16 text-center">
            <div className="text-xs font-bold uppercase tracking-[0.2em] mb-4 inline-flex items-center gap-2" style={{ color: '#60A5FA' }}>
              <Zap size={14} />
              SIMPLE PRICING
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white mb-6">Choose Your Plan</h2>
            <p className="text-lg sm:text-xl max-w-2xl mx-auto" style={{ color: '#94A3B8' }}>
              Start for free, upgrade when you need more power and customization.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Koara Basic */}
            <div className="glass-card p-10 flex flex-col relative group">
              <div className="mb-8">
                <h3 className="text-2xl font-bold text-white mb-2">Koara Basic</h3>
                <div className="text-4xl font-extrabold text-white mb-4">FREE</div>
                <div className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-2" style={{ background: 'rgba(59,130,246,0.1)', color: '#60A5FA', border: '1px solid rgba(59,130,246,0.2)' }}>
                  Free for a limited time.
                </div>
                <p className="text-xs mt-2" style={{ color: '#64748B' }}>This plan will become paid in the future.</p>
              </div>

              <div className="flex-1 space-y-4 mb-8">
                {[
                  'Default storefront theme',
                  'Default email template',
                  'Free Koara subdomain',
                  'Order management',
                  'Basic merchant dashboard'
                ].map((feature, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <ShieldCheck size={18} style={{ color: '#60A5FA' }} />
                    <span className="text-sm text-slate-300">{feature}</span>
                  </div>
                ))}
              </div>

              <button onClick={() => setIsOnboardingOpen(true)} className="dash-btn w-full justify-center py-4 rounded-xl font-semibold" style={{ background: 'rgba(255,255,255,0.05)', color: 'white', border: '1px solid rgba(255,255,255,0.1)' }}>
                Get Started Free
              </button>
            </div>

            {/* Koara Plus */}
            <div className="glass-card p-10 flex flex-col relative transform md:-translate-y-4 shadow-2xl" style={{ border: '1px solid rgba(59,130,246,0.4)', background: 'rgba(15,23,42,0.8)' }}>
              {/* Most Popular Badge */}
              <div className="absolute top-0 end-8 transform -translate-y-1/2">
                <div className="px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider" style={{ background: 'linear-gradient(135deg, #2563EB, #4F46E5)', color: 'white', boxShadow: '0 4px 15px rgba(37,99,235,0.4)' }}>
                  Most Popular
                </div>
              </div>

              <div className="absolute inset-0 pointer-events-none rounded-2xl" style={{ background: 'radial-gradient(circle at top right, rgba(59,130,246,0.15), transparent 70%)' }}></div>

              <div className="mb-8 relative z-10">
                <h3 className="text-2xl font-bold text-white mb-2">Koara Plus</h3>
                <div className="flex items-end gap-2 mb-6">
                  <div className="text-4xl font-extrabold text-white">$4.99</div>
                  <div className="text-sm font-medium pb-1" style={{ color: '#94A3B8' }}>/ month</div>
                </div>
              </div>

              <div className="flex-1 space-y-4 mb-8 relative z-10">
                {[
                  'Remove ALL Koara branding',
                  'Connect your own custom domain',
                  'Automatic monthly reports',
                  'Full storefront customization',
                  'Full email branding customization',
                  'Discount codes & promotional campaigns',
                  'Early access to new features'
                ].map((feature, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className="mt-0.5 shrink-0">
                      <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: 'rgba(59,130,246,0.2)' }}>
                        <div className="w-2 h-2 rounded-full" style={{ background: '#60A5FA' }}></div>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-white">{feature}</span>
                  </div>
                ))}
              </div>

              <button onClick={() => setIsOnboardingOpen(true)} className="dash-btn w-full justify-center py-4 rounded-xl font-bold text-white relative z-10 transition-all hover:scale-[1.02]" style={{ background: 'linear-gradient(135deg, #2563EB, #4F46E5)', boxShadow: '0 4px 15px rgba(37,99,235,0.3)' }}>
                Upgrade to Plus
              </button>
            </div>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════════════════
            FAQ SECTION
        ═══════════════════════════════════════════════════════════════ */}
        <section className="max-w-3xl mx-auto px-4 sm:px-8 py-20 sm:py-28 relative z-10 section-glow fade-in-section">
          <div className="mb-12 text-center">
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mb-4">Frequently Asked Questions</h2>
            <p className="text-slate-400">Everything you need to know about the product and billing.</p>
          </div>

          <div className="flex flex-col">
            {[
              { q: "What is Koara?", a: "Koara is a unified digital commerce platform designed for the MENA region, enabling merchants to sell digital products, manage KYC, and process payments instantly." },
              { q: "How do merchants receive payments?", a: "Merchants can link their local bank accounts or supported digital wallets. We handle the settlement processing automatically." },
              { q: "Which countries are supported?", a: "We currently support merchants across major MENA countries with rapid expansion plans for additional regions." },
              { q: "How long does KYC take?", a: "Most verifications are processed within 24 hours. Our automated systems handle basic checks instantly." },
              { q: "What payment methods are supported?", a: "We support local bank transfers, major credit cards, and popular regional digital wallets." },
              { q: "Is there a monthly subscription?", a: "You can start for free on our Basic plan. Our Plus plan offers advanced customization and zero platform branding for a small monthly fee." }
            ].map((faq, index) => (
              <FAQItem
                key={index}
                question={faq.q}
                answer={faq.a}
                isOpen={openFaq === index}
                onClick={() => setOpenFaq(openFaq === index ? null : index)}
              />
            ))}
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════════════════
            CTA SECTION
        ═══════════════════════════════════════════════════════════════ */}
        <section className="max-w-7xl mx-auto px-4 sm:px-8 py-20 sm:py-28 relative z-10 fade-in-section">
          <div className="rounded-[2rem] p-12 sm:p-16 text-center relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #0B1220 0%, #080D18 50%, #0B1220 100%)', border: '1px solid rgba(255,255,255,0.04)' }}>
            {/* Background glow */}
            <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
              <div className="absolute top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2 w-[60%] h-[60%] bg-gradient-to-br from-[#2563EB]/20 via-[#4F46E5]/10 to-transparent blur-[80px] rounded-full"></div>
            </div>

            <div className="relative z-10">
              <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white mb-6">
                Ready to transform your<br />digital commerce?
              </h2>
              <p className="text-lg max-w-xl mx-auto mb-10" style={{ color: '#94A3B8' }}>
                Join thousands of merchants already selling on Koara. Set up your store in minutes.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full px-4 sm:px-0">
                <button
                  onClick={() => setIsOnboardingOpen(true)}
                  className="btn-primary px-10 py-4 text-base flex items-center justify-center gap-2 w-full sm:w-auto"
                >
                  Get started free <ArrowRight size={18} className="rtl:rotate-180" />
                </button>
                <button
                  className="btn-secondary px-8 py-4 text-sm w-full sm:w-auto text-center"
                  onClick={() => {
                    window.location.href = "mailto:support@getkoara.com";
                  }}
                >
                  Talk to sales
                </button>

              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => { setIsOnboardingOpen(false); setOnboardingInitialData(null); }}
        initialData={onboardingInitialData}
      />
      <LoginModal
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        onStoreStatus={setStoreRequestStatus}
        onForgot={() => setIsPasswordResetOpen(true)}
        onGoogleOnboarding={(email) => {
          setOnboardingInitialData({ isGoogleAuth: true, email });
          setIsOnboardingOpen(true);
        }}
      />
      <PasswordResetModal isOpen={isPasswordResetOpen} onClose={() => setIsPasswordResetOpen(false)} />
      <StoreStatusModal isOpen={!!storeRequestStatus} onClose={() => setStoreRequestStatus(null)} storeRequestStatus={storeRequestStatus} />
    </div>
  );
};

export default LandingPage;
